// -------------------------------------------------------------------------------------------
// CODE FILENAME: Stash-assn4-funcs.cpp 
//
// DESCRIPTION:   MStash function file for Assignment 4
//
// CLASS/TERM:    CS372 Summer 16 8W1
//
// DESIGNER: 	  Matt Stash
// -------------------------------------------------------------------------------------------


#include <iostream>
#include <iomanip>
#include <cstdlib>
#include <ctime>
#include "StahleyStash-assn4-common.h"
#include "Stash-assn4-funcs.h"

// -------------------------------------------------------------------------------------------
// FUNCTION: 	  GenerateRandomArray
//
// DESCRIPTION:   Initializes an array with random integers
//							   
// INPUT:		  int unsortedList[] - The list being initialized
//
// CALLS TO:	  RandomNumber
// -------------------------------------------------------------------------------------------
void GenerateRandomArray(int* firstList, int* secondList) {
	
	srand(time(0));							// seeds random number generator
	
	int temp,
		count = 0;
	
	while (count < ARRAY_SIZE) {
		
		temp = RandomNumber();
		
		firstList[count] = temp;
		secondList[count] = temp;
		
		count++;
	}
	return;
}

// -------------------------------------------------------------------------------------------
// FUNCTION: 	  RandomNumber
//
// DESCRIPTION:   Creates a random number between the constant min and max values
// -------------------------------------------------------------------------------------------
int RandomNumber() {
	
	return rand() % MAX_VALUE + MIN_VALUE;
} 

// -------------------------------------------------------------------------------------------
// FUNCTION: 	  CalculateAverage
//
// DESCRIPTION:   Calculates the average time for the number of clocks ticks with the number 
//				  of runs
// -------------------------------------------------------------------------------------------
float CalculateAverage(int clockTicks[], int numRuns)
{	
	int total = 0;
	
	for (int i = 0; i < numRuns; i++) {
		
		total += clockTicks[i];
	}
	
	return (float) total / numRuns;
}
// -------------------------------------------------------------------------------------------
// FUNCTION: 	  DisplayResults
//
// DESCRIPTION:   Displays the results of the sorting tests
//
// INPUT:		  string firstTest - String title for the first sort tested
//				  string secondTest - String title for the second sort tested
//				  int firstAvg - 
// -------------------------------------------------------------------------------------------
void DisplayResults(string firstTest, string secondTest, float firstAvg, float secondAvg){

	
	cout << setprecision(7);
	cout << "SORTING RESULTS" << endl;
	cout << setw(15) << setfill('-') << "-" << setfill(' ') << endl;
	cout << setw(20) << firstTest << setw(12) 
								  << firstAvg << " clock ticks on average" << endl;
	cout << setw(20) << secondTest << setw(12) 
								   << secondAvg << " clock ticks on average" << endl << endl;
	
	return;
}

// -------------------------------------------------------------------------------------------
// FUNCTION: 	  InsertionSort
//
// DESCRIPTION:   Performs a insertion sort on an array
//
// INPUT:		  int* unsortedArray - Pointer to a unsorted array
// -------------------------------------------------------------------------------------------
void InsertionSort(int* unsortedArray, int low, int high) {
	
	int remainTop, temp;
	
	for (int i = low; i <= high; i++) {
		
		remainTop = i;
		
		while (remainTop > low && unsortedArray[remainTop] < unsortedArray[remainTop - 1]) {
			
			temp = unsortedArray[remainTop];
			unsortedArray[remainTop] = unsortedArray[remainTop - 1];
			unsortedArray[remainTop - 1] = temp;
			
			remainTop--;
		}
	}
	return;
}

// -------------------------------------------------------------------------------------------
// FUNCTION: 	  MergeSort
//
// DESCRIPTION:   Performs a merge sort on an array
//
// INPUT:		  int* unsortedArray - Pointer to a unsorted array
//				  int low - Low index of the array
//				  int high - High index of the array
// -------------------------------------------------------------------------------------------
void MergeSort(int* unsortedArray, int low, int high) {
	
	int middle;
	
	if (low < high) {
		
		middle = (low + high) / 2;
		
		MergeSort(unsortedArray, low, middle);
		MergeSort(unsortedArray, middle + 1, high);
		Merge(unsortedArray, low, middle, high);
	}
	return;
}

// -------------------------------------------------------------------------------------------
// FUNCTION: 	  Merge
//
// DESCRIPTION:   Performs the merge as part of the merge sort
// 
// INPUT:		  int* unsortedArray - Pointer to a unsorted array
//				  int low - Low index of the array
//				  int middle - Middle index of the array
//				  int high - High index of the array
// -------------------------------------------------------------------------------------------
void Merge(int* unsortedArray, int low, int middle, int high) {
	
	int left = low,
		right = middle + 1,
		temp = low,
		size = high - low;
	
	int tempArray[size];
	
	while (left <= middle && right <= high) {
		
		if (unsortedArray[left] <= unsortedArray[right]) {
			
			tempArray[temp] = unsortedArray[left];
			left++;
		
		} else {
			
			tempArray[temp] = unsortedArray[right];
			right++	;
		}
		temp++;
	}
	
	while (left <= middle) {
		
		tempArray[temp] = unsortedArray[left];
		temp++;
		left++;
	}
	
	while (right <= high) {
		
		tempArray[temp] = unsortedArray[right];
		temp++;
		right++;
	}
	
	for (left = low; left < temp; left++) {
		
		unsortedArray[left] = tempArray[left];
	}
	
	cout << "";
	return;
}
