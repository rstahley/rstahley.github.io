#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;

#include "StahleyStash-assn4-common.h"
#include "Stahley-assn4-funcs.h"
#include "Stash-assn4-funcs.h"

//********************************************************************************
//  FUNCTION:	  main
//  DESCRIPTION:  Initiates program & calls all other functions
//  INPUT:        Parameters: None
//  OUTPUT: 	  Return value: 0 indicating program exited successfully
//  CALLS TO:	  GenerateRandomArray, Menu, DestroyArray
//  IMPLEMENTED BY: Stash
//*******************************************************************************

int main()
{
	int* firstArray = new int[ARRAY_SIZE];
	int* secondArray = new int[ARRAY_SIZE];
	
	GenerateRandomArray(firstArray, secondArray);
	
	Menu (firstArray, secondArray);
	
	DestroyArray (firstArray);
	DestroyArray (secondArray);

	return 0;
}
