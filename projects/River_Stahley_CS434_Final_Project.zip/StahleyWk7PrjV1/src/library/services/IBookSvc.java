/* 
* File Name: IBookSvc.java
* Description: Book Service Interface
* @author: River Stahley
* @version: 01, Assignment 8
*/

package library.services;
import library.domain.*;

/*
* Book service interface with Add(method)
*   that throws a general Exception &
*   extends the IService marker interface
*/

public interface IBookSvc extends IService {
    public Book add(Book book) throws Exception; 
}