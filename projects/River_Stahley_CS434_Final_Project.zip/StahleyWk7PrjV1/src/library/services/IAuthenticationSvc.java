/* 
* File Name: IAuthenticationSvc.java
* Description: Authentication Service Interface
* @author: River Stahley
* @version: 01, Assignment 8
*/

package library.services;

import domain.Login;

/*
* Authentication service interface with authenticate method
*   extends IService base interface
*/

public interface IAuthenticationSvc extends IService {
    public boolean authenticate(Login login);
}