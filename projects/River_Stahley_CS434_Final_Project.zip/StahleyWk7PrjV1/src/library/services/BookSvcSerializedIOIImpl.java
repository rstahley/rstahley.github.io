/* 
* File Name: BookSvcSerializedIOImpl.java
* Description: Book Service Implementation
* @author: River Stahley
* @version: 01, Assignment 8
*/

package library.services;
import java.io.*;
import library.domain.*;

public class BookSvcSerializedIOIImpl implements IBookSvc {
    
    /*
    * overridden method - implements IBookSvc interface,
    *       throws general Exception
    *   @param: book
    *   @return: book
    */
    
    @Override
    public Book add(Book book) throws Exception{
       FileOutputStream file = new FileOutputStream("books.txt");
       ObjectOutputStream output = new ObjectOutputStream(file);
       output.writeObject(book);
       output.flush();
       output.close();
       
       return book; 
    }
}