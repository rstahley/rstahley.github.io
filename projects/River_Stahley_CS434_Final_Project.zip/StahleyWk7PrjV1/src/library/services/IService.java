/* 
* File Name: IService.java
* Description: Marker Interface
* @author: River Stahley
* @version: 01, Assignment 8
*/

package library.services;

public interface IService {
    
    /**
     * base service interface - has no methods
     */   
}