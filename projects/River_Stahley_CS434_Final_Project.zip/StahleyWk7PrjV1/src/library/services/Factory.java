/* 
* File Name: Factory.java
* Description: Instantiates/Returns implementation for Book Service
* @author: River Stahley
* @version: 01, Assignment 8
*/

package library.services;

import java.io.*;
import java.util.*;

public class Factory {
    
    public Factory() {}
    
    /*
    * calls getImplName, loads the implementation class via Class.forName &
    *   dynamically creates a new instance of the impl class via newInstance
    */
    
    public IService getService(String serviceName) throws Exception {
        Class c = Class.forName(getImplName(serviceName));
        return (IService) c.newInstance();
    }
    
    /*
    * loads config file into a Properties object & retrieves and returns
    *   the implementation class name from the loaded Properties
    */
    
    private String getImplName(String serviceName) throws Exception {
        FileInputStream file = new FileInputStream("config/properties.txt");
        Properties props = new Properties();
        props.load(file);
        file.close();
        return props.getProperty(serviceName);
    }
}