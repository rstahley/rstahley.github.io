/* 
* File Name: AuthenticationSvcSocketImpl.java
* Description: Authentication Service Socket Implementation
* @author: River Stahley
* @version: 01, Assignment 8
*/

package library.services;

import java.io.*;
import java.net.*;
import domain.Login;

public class AuthenticationSvcSocketImpl implements IAuthenticationSvc {
   
    /*
    * overridden method - implements IAuthenticationSvc interface,
    *   connects to authentication server passing username and password    
    *   @param: login
    *   @return: validated - boolean
    */
    
    @Override
    public boolean authenticate(Login login){
        Socket socket = null;
        ObjectInputStream in = null;
        ObjectOutputStream out = null;
        boolean validated = false;
        
        try {
            socket = new Socket(InetAddress.getLocalHost(), 8000);
            in = new ObjectInputStream(socket.getInputStream());
            out = new ObjectOutputStream(socket.getOutputStream());
            out.writeObject(login);
            boolean authenticate = (Boolean)in.readObject();
            
            if (authenticate != validated) {
                validated = true;
            }
                               
        } catch(Exception e) {
            System.out.println("Exception " + e.getMessage());
        } finally {
            try {
                in.close();
                out.close();
                socket.close();
            } catch(Exception e) {
                System.out.println("Exception " + e.getMessage());
            }
        }
        
        return validated;
    }
}