/* 
* File Name: BookSvcSerializedIOImpl.java
* Description: Book Service Database Implementation
* @author: River Stahley
* @version: 01, Assignment 8
*/

package library.services;

import java.sql.*;
import javax.sql.*;
import library.domain.*;

public class BookSvcJDBCImpl implements IBookSvc {
    
    private String connString = "jdbc:mysql://localhost:3306/stahleylibrary?"
            + "user=root&password=admin&useSSL=false";
    
    private Connection getConnection() throws Exception {
        return DriverManager.getConnection(connString);
    }
    
    /*
    * overridden method - implements IBookSvc interface,
    *       throws general Exception - adds book to database
    *   @param: book
    *   @return: book
    */
    
    @Override
    public Book add(Book book) throws Exception{
        Connection conn = getConnection();
        try {
            Statement stmt = conn.createStatement();
            String sql = "INSERT INTO book (authors, isbn) " + 
                "VALUES ('" + book.getAuthors() + "', '" +
			    book.getIsbn() + "' )";
            stmt.executeUpdate(sql);
        } catch(Exception e) {
            throw e;
        } finally {
            if (conn != null) conn.close();
        }
    
        return book;
    }   
}