/* 
* File Name: BookUI.java
* Description: Presentation layer - user interface
* @author: River Stahley
* @version: 01, Assignment 8
*/

package library.presentation;

import javax.swing.*;
import java.awt.*;
import java.awt.GraphicsEnvironment;
import java.awt.event.*;
import java.util.Arrays;
import java.util.ArrayList;
import library.domain.Book;
import library.business.BookMgr;

public class BookUI extends JFrame{
    
    private JLabel delimiterLbl;
    private JLabel authorsLbl;
    private JLabel isbnLbl;
    private JTextField authorsFld;
    private JTextField isbnFld;
    private JButton addBtn;
    private JButton cancelBtn;
    
    /*
    * Parameterized constructor
    */
    
    public BookUI(String title){
        super(title);
        
        // Add Book Class fields to GUI using a GridBagLayout
        
        Container container = getContentPane();
        GridBagLayout layout = new GridBagLayout();
        container.setLayout(layout);
        GridBagConstraints constraints = new GridBagConstraints();
        
        delimiterLbl = new JLabel("Enter a comma between authors names");
        delimiterLbl.setFont(new Font("Serif", Font.BOLD, 17));
        constraints.gridx = 1;
        constraints.gridy = 0;
        constraints.anchor = GridBagConstraints.CENTER;
        container.add(delimiterLbl, constraints);
        
        
        authorsLbl = new JLabel("Author(s):");
        authorsLbl.setFont(new Font("Serif", Font.ITALIC, 15));
        constraints.gridx = 0;
        constraints.gridy = 1;
        container.add(authorsLbl, constraints);
        
        authorsFld = new JTextField(25);
        constraints.gridx = 1;
        constraints.gridy = 1;
        container.add(authorsFld, constraints);
        
        isbnLbl = new JLabel("ISBN:");
        isbnLbl.setFont(new Font("Serif", Font.ITALIC, 15));
        constraints.gridx = 0;
        constraints.gridy = 2;
        container.add(isbnLbl, constraints);
        
        isbnFld = new JTextField(25);
        constraints.gridx = 1;
        constraints.gridy = 2;
        constraints.anchor = GridBagConstraints.CENTER;
        container.add(isbnFld, constraints);
        
        addBtn = new JButton("Add");
        constraints.gridx = 1;
        constraints.gridy = 3;
        constraints.anchor = GridBagConstraints.LINE_START;
        container.add(addBtn, constraints);
        
        cancelBtn = new JButton("Cancel");
        constraints.gridx = 1;
        constraints.gridy = 3;
        constraints.anchor = GridBagConstraints.EAST;
        container.add(cancelBtn, constraints);
        
        /*
        * event listener - anonymous class for cancel button
        */
        
        cancelBtn.addActionListener(new ActionListener(){
            
            /*
            * overridden method - sets text fields to empty
            *   displays confirmation message to the console 
            *       @param: e
            */
            
            @Override
            public void actionPerformed(ActionEvent e){
                authorsFld.setText("");
                isbnFld.setText("");
                System.out.println("Cancel button pressed.");
            }
        });
        
        /*
        * event listener - class for add button
        */
        
        class OkActionListener implements ActionListener{
           
           /*
           * overridden method - places user inputted data into
           *   a Book object and displays the state of the object
           *   by calling the overridden toString() method
           *    @param: ex
           */
            
           @Override
            public void actionPerformed(ActionEvent ex){
                try{
                   Book book = new Book();
                   String author[] = authorsFld.getText().split(",");
                   ArrayList<String> authors = new ArrayList<>(Arrays.
                           asList(author));
                   book.setAuthors(authors);
                   book.setIsbn(isbnFld.getText());
                   System.out.println("Add Button Clicked.");
                   
                   // if book object is valid, object is sent to BookMgr 
                         
                   if (book.validate() != false){
                       BookMgr bookMgr = new BookMgr();
                       Book storeBook = bookMgr.storeBook(book);
                       System.out.println(storeBook.toString());
                   }
                   
                   // else exception is triggered - error message is displayed
                   // to the user
                   
                   else{
                       Exception e = new Exception("Error - invalid input!"
                               + " One or both entries are empty and/or null");
                       throw e;
                   }
                } catch (Exception e){
                    JOptionPane.showMessageDialog(rootPane, e.getMessage());
                }  
            }
        }
        
        OkActionListener okActionListener = new OkActionListener();
        addBtn.addActionListener(okActionListener);            
    }
    
    /*
    * Creates, sizes, centers and shows the BookUI object
    *   @param: args
    */
        
    public static void main(String[] args){
        BookUI book = new BookUI("Enter Book Information");
        book.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        book.setSize(450,300);
        book.setLocationRelativeTo(null);
        book.setVisible(true); 
    }
}