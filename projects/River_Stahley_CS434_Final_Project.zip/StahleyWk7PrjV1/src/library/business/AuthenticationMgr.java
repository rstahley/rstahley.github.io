/* 
* File Name: AuthenticationMgr.java
* Description: Authentication Manager
* @author: River Stahley
* @version: 01, Assignment 8
*/

package library.business;

import domain.Login;
import library.services.*;

/*
 * authenticates username and password
 *   @param: login
 *   @return: validated - boolean
 */

public class AuthenticationMgr {
    public boolean authenticate(Login login){
        
        boolean validated = false;
        
        try {
            Factory factory = new Factory();
            IAuthenticationSvc authenticationSvc = (IAuthenticationSvc)
                    factory.getService("IAuthenticationSvc");
            boolean authenticate = authenticationSvc.authenticate(login);
            
            if (authenticate != validated) {
                validated = true;
            }
               
         } catch(Exception e) {
             System.out.println("Exception " + e.getMessage());
         }
        
        return validated;
    }
}