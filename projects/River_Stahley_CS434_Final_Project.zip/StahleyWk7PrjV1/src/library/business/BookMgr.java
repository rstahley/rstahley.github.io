/* 
* File Name: BookMgr.java
* Description: Business layer manager
* @author: River Stahley
* @version: 01, Assignment 8
*/

package library.business;

import library.services.*;
import library.domain.*;

/*
 * executes user request for "Add Book"
 *   @param: book
 *   @return: book
 */

public class BookMgr {
    
    public Book storeBook(Book book) throws Exception{
        Factory factory = new Factory();
        IBookSvc bookSvc = (IBookSvc)factory.getService("IBookSvc");
        return bookSvc.add(book);
    }  
}