/* 
* File Name: Book.java
* Description: Book class for Library application that holds two values:
*              the book isbn and a collection of authors.
* @author: River Stahley
* @version: 01, Assignment 8
*/

package library.domain;

import java.util.ArrayList;
import java.util.Objects;

public class Book implements java.io.Serializable {
    private ArrayList<String> authors;
    private String isbn;
    
    /*
    * Default constructor
    */
    
    public Book(){
        authors = null;
        isbn = null;
    }
    
    /*
    * Parameterized constructor
    */
    
    public Book(ArrayList<String> authors, String isbn){
        this.authors = authors;
        this.isbn = isbn;
    }
    
    /*
    * Gets author(s) variable
    *   @return: authors
    */
    
    public ArrayList<String> getAuthors(){
        return authors;
    }
    
    /*
    * Sets value of author(s) variable
    *   @param: authors
    */
    
    public void setAuthors(ArrayList<String> authors){
        this.authors = authors;
    }
    
    /*
    * Gets isbn variable
    *   @return: isbn
    */
    
    public String getIsbn(){
        return isbn;
    }
    
    /*
    * Sets value of isbn variable
    *   @param: isbn
    */
    
    public void setIsbn(String isbn){
        this.isbn = isbn;
    }
    
    /*
    * overridden method - compares the state of two objects
    *   @param: obj
    *   @return: true - if their state is the same
    *            false - if not
    */
    
    @Override
    public boolean equals(Object obj){
        if (this == obj) return true;
        if (!(obj instanceof Book)) return false;
        Book book = (Book)obj;
        if (! this.getAuthors().equals(book.getAuthors())) return false;
        if (! this.isbn.equals(book.isbn)) return false;
        return true;
    }
    
    /*
     * overridden method - determines the equality of keys
     *  @return: hash
     */

    @Override
    public int hashCode() {
        int hash = 3;
        hash = 83 * hash + Objects.hashCode(this.authors);
        hash = 83 * hash + Objects.hashCode(this.isbn);
        return hash;
    }
    
    /*
    * Determines whether an object instance is in a valid state or not 
    *   @return: true - if data members are in a valid state
    *            false - if not
    */
    
    public boolean validate(){
        if (authors == null || authors.isEmpty()) return false;
        if (isbn == null || isbn.equals("")) return false;
        return true;
    }
    
    /*
     * overridden method - returns state of Book object
     *  @return: values of authors & isbn
     */
    
    @Override
    public String toString(){
        return "Author(s): " + this.authors + ", ISBN: " + this.isbn;
    }
}