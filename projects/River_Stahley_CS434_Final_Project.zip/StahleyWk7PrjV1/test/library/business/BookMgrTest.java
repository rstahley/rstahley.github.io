/*
 * File Name: BookMgrTest.java
 * Description: Tests BookMgr class - BookMgr.java
 * @author: River Stahley
 * @version: 01, Assignment 8
*/

package library.business;

import java.util.ArrayList;
import library.domain.Book;
import org.junit.Test;
import static org.junit.Assert.*;

public class BookMgrTest {
    
    private ArrayList<String> authors = new ArrayList<>();

    /**
     * Test of storeBook method, of class BookMgr - equality & not null
     *      condition
     */
    
    @Test
    public void testStoreBookEqualsNotNull() {
        System.out.println("storeBookEqualsNotNull");
        
        try{
            authors.add("Bravaco");
            authors.add("Simonson");
            Book book = new Book (authors, "9780073523354");
            BookMgr instance = new BookMgr();
            Book expResult = book;
            assertNotNull(expResult);
            Book result = instance.storeBook(book);
            assertNotNull(result);
            assertEquals(expResult, result); 
        } catch(Exception e){
            System.out.println("Error: Domain object & stored book"
                    + " don't match");
            e.printStackTrace();
        }   
    }    
}