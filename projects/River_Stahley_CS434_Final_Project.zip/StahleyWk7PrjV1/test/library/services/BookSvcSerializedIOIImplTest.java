/*
 * File Name: BookSvcSerializedIOIImplTest.java
 * Description: Tests BookSvcSerializedIOIImpl class - 
 *      BookSvcSerializedIOIImpl.java
 * @author: River Stahley
 * @version: 01, Assignment 8
*/

package library.services;

import java.lang.AssertionError;
import java.util.ArrayList;
import library.domain.Book;
import org.junit.Test;
import static org.junit.Assert.*;

public class BookSvcSerializedIOIImplTest {

    private ArrayList<String> authors = new ArrayList<>();
    
    /**
     * Test of add method, of class BookSvcSerializedIOIImpl -
     *      equality & not null condition
     */
    
    @Test
    public void testAddEqualsNotNull() {
        System.out.println("addEqualsNotNull");
        
        try{
            authors.add("Bravaco");
            authors.add("Simonson");
            Book book = new Book (authors, "9780073523354");
            Factory instance = new Factory();
            IBookSvc bookSvc = (IBookSvc)instance.getService("IBookSvc");
            Book result = bookSvc.add(book);
            assertNotNull(book);
            assertNotNull(result);
            assertEquals(book, result);   
        } catch(Exception e){
            System.out.println("Error: Domain object & stored book"
                    + " don't match");
            e.printStackTrace();
        }    
    }
    
    /**
     * Test of add method, of class BookSvcSerializedIOIImpl -
     *      exception condition
     */
    
    @Test (expected = AssertionError.class)
    public void testAddException() {
        System.out.println("addException");
        
        try{
            authors.add("Bravaco");
            authors.add("Simonson");
            Book book = new Book (authors, "9780073523354");
            BookSvcSerializedIOIImpl instance = new BookSvcSerializedIOIImpl();
            Book expResult = null;
            Book result = instance.add(book);
            assertEquals(expResult, result);
        } catch(Exception e){
            System.out.println("Error: Domain object & stored book"
                    + " don't match");
            e.printStackTrace();
        }  
    }   
}