/*
 * File Name: BookSvcJDBCImplTest.java
 * Description: Inserts data into stahleylibrary database
 * @author: River Stahley
 * @version: 01, Assignment 8
*/

package library.services;

import library.domain.Book;
import org.junit.Test;
import java.sql.*;
import java.util.ArrayList;
import static org.junit.Assert.*;

public class BookSvcJDBCImplTest {
    
    /**
     * Test of add method, of class BookSvcJDBCImpl.
     */
    
    private ArrayList<String> authors = new ArrayList<>();
    
    @Test
    public void testAdd() {
        System.out.println("add");
        try{
           authors.add("Bravaco");
            Book book = new Book(authors, "9781019988");
            Factory instance = new Factory();
            IBookSvc bookSvc = (IBookSvc) instance.getService("IBookSvc");
            Book result = bookSvc.add(book);
            assertNotNull(book);
            assertNotNull(book);
            assertEquals(book, result); 
        } catch(Exception e){
            System.out.println("Error: Domain object & stored book"
                    + " don't match");
            e.printStackTrace();
        }  
    }   
}