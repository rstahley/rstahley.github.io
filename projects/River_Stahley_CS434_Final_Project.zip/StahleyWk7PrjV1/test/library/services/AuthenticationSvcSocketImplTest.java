/*
 * File Name: AuthenticationSvcSocketImplTest.java
 * Description: Tests Socket Implementation - AuthenticationSvcSocketImpl.java
 * @author: River Stahley
 * @version: 01, Assignment 8
*/

package library.services;

import domain.Login;
import org.junit.Test;
import static org.junit.Assert.*;

public class AuthenticationSvcSocketImplTest {
    
    /**
     * Test of authenticate method, of class AuthenticationSvcSocketImpl
     *      valid credentials
     */
    
    @Test
    public void testAuthenticateValid() {
        System.out.println("authenticateValid");
        Login login = new Login("root", "admin");
        AuthenticationSvcSocketImpl instance = new AuthenticationSvcSocketImpl();
        boolean expResult = true;
        boolean result = instance.authenticate(login);
        assertEquals(expResult, result);
    }
    
    /**
     * Test of authenticate method, of class AuthenticationSvcSocketImpl
     *      invalid credentials
     */
    
    @Test
    public void testAuthenticateInvalid() {
        System.out.println("authenticateInvalid");
        Login login = new Login("admin", "root");
        AuthenticationSvcSocketImpl instance = new AuthenticationSvcSocketImpl();
        boolean expResult = false;
        boolean result = instance.authenticate(login);
        assertEquals(expResult, result);
    }  
}