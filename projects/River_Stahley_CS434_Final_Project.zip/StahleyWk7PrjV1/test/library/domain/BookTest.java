/*
 * File Name: BookTest.java
 * Description: Tests Book class - Book.java
 * @author: River Stahley
 * @version: 01, Assignment 8
*/

package library.domain;

import java.util.ArrayList;
import org.junit.Test;
import static org.junit.Assert.*;

public class BookTest {
    
    private ArrayList<String> authors = new ArrayList<>();
    
    /**
     * Test of equals method, of class Book - true condition
     */
    
    @Test
    public void testEqualsTrue() {
        System.out.println("equalsTrue");
        authors.add("Ralph Bravaco");
        authors.add("Shai Simonson");
        Object obj = new Book (authors, "9780073523354");
        Book instance = new Book(authors, "9780073523354");
        boolean expResult = true;
        boolean result = instance.equals(obj);
        assertEquals(expResult, result);
    }
    
    /**
     * Test of equals method, of class Book - false condition
     */
    
    @Test
    public void testEqualsFalse() {
        System.out.println("equalsFalse");
        authors.add("Ralph Bravaco");
        authors.add("Shai Simonson");
        Object obj = new Book (authors, "9780073523354");
        Book instance = new Book(authors, "978101541289");
        boolean expResult = false;
        boolean result = instance.equals(obj);
        assertEquals(expResult, result);
    }
    
    /**
     * Test of validate method, of class Book - true condition
     */
    
    @Test
    public void testValidateTrue() {
        System.out.println("validateTrue");
        Book instance = new Book();
        boolean expResult = false;
        boolean result = instance.validate();
        assertEquals(expResult, result);
        authors.add("Ralph Bravaco");
        authors.add("Shai Simonson");
        instance.setAuthors(authors);
        instance.setIsbn("9780073523354");
        result = instance.validate();
        assertEquals("expected true", true, result);
    } 

    /**
     * Test of validate method, of class Book - false condition
     */
    
    @Test
    public void testValidateFalse() {
        System.out.println("validateFalse");
        Book instance = new Book();
        boolean expResult = false;
        boolean result = instance.validate();
        assertEquals(expResult, result);
        authors.add("Ralph Bravaco");
        authors.add("Shai Simonson");
        instance.setAuthors(null);
        instance.setIsbn("");
        result = instance.validate();
        assertEquals("expected true", false, result);
    }  
}