/* 
* File Name: AuthenticationServer.java
* Description: Authentication Server
* @author: River Stahley
* @version: 01, Assignment 8
*/

import business.*;

public class AuthenticationServer {

    /**
     * instantiates a new ConnectionMgr which calls its listen() method
     */
    
    public static void main(String[] args)  {
        ConnectionMgr connectionMgr = new ConnectionMgr();
        connectionMgr.listen();   
    }   
}