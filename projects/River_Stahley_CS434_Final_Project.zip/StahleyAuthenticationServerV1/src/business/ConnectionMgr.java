/* 
* File Name: ConnectionMgr.java
* Description: Connection Manager
* @author: River Stahley
* @version: 01, Assignment 8
*/

package business;

import java.io.*;
import java.net.*;

/*
 * Coordinates the processing of socket requests on the authentication server
*/

public class ConnectionMgr {
    
    public void listen() {
    
        ServerSocket server = null;
        Socket socket = null;
        SocketMgr socketMgr = new SocketMgr(socket);
        ObjectInputStream in = null;
        ObjectOutputStream out = null;
    
        try {
            server = new ServerSocket(8000);
            socket = server.accept();
            
            // call Socket Manager
            
            socketMgr.process(socket);
            
            in.close();
            out.close();
            socket.close();
        
        } catch(Exception e){
            System.out.println("Exception " + e.getMessage());  
        }   
    }
}