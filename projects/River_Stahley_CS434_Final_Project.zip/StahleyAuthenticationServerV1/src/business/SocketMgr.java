/* 
* File Name: SocketMgr.java
* Description: Socket Manager
* @author: River Stahley
* @version: 01, Assignment 8
*/

package business;

import java.io.*;
import java.net.*;
import domain.Login;

public class SocketMgr {
    
    public Socket clientSocket = null;
    public boolean validated;
    private String userName = "root";
    private String password = "admin";
    
    /*
    * Parameterized constructor
    */
    
    public SocketMgr(Socket clientSocket) {
        this.clientSocket = clientSocket;
        validated = false;
    }
    
    /*
     * gets username and password & authenticates both against hardcoded
     *      user credentials
     *   @param: clientSocket - Socket
     *   @return: validated - boolean
    */
    
    public boolean process(Socket clientSocket) {
       ObjectInputStream in = null;
       ObjectOutputStream out = null;
       
       try {
            out = new ObjectOutputStream(clientSocket.getOutputStream());
            in = new ObjectInputStream(clientSocket.getInputStream());
            
            Login login = (Login)in.readObject();
            
            System.out.println(login);
            
            if (login.getUserName().equals(userName) && login.getPassword().equals(password)) {
                validated = true;
                out.writeObject(validated);
            }
                 
       } catch (Exception e) {
           System.out.println("Exception " + e.getMessage());   
       }
       
       return validated;
      
    }   
}