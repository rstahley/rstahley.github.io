/* 
* File Name: Login.java
* Description: Common Login class that is referenced by Authentication Server
*       & client application
* @author: River Stahley
* @version: 01, Assignment 8
*/

package domain;

import java.util.Objects;

public class Login implements java.io.Serializable {
    public String username;
    private String password;
    
    /*
    * Default constructor
    */
    
    public Login(){
        username = null;
        password = null;
    }
    
    /*
    * Parameterized constructor
    */
    
    public Login(String username, String password){
        this.username = username;
        this.password = password;
    }
    
    /*
    * Gets username variable
    *   @return: username
    */
    
    public String getUserName(){
        return username;
    }
    
    /*
    * Sets value of username variable
    *   @param: username
    */
    
    public void setUserName(String username){
        this.username = username;
    }
    
    /*
    * Gets password variable
    *   @return: password
    */
    
    public String getPassword(){
        return password;
    }
    
    /*
    * Sets value of password variable
    *   @param: password
    */
    
    public void setPassword(String password){
        this.password = password;
    }
    
    /*
    * overridden method - compares the state of two objects
    *   @param: obj
    *   @return: true - if their state is the same
    *            false - if not
    */
    
    @Override
    public boolean equals(Object obj){
        if (this == obj) return true;
        if (!(obj instanceof Login)) return false;
        Login login = (Login)obj;
        if (! this.getUserName().equals(login.getUserName())) return false;
        if (! this.password.equals(login.password)) return false;
        return true;
    }
    
    /*
     * overridden method - determines the equality of keys
     *  @return: hash
     */

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 13 * hash + Objects.hashCode(this.username);
        hash = 13 * hash + Objects.hashCode(this.password);
        return hash;
    }
    
    /*
    * Determines whether an object instance is in a valid state or not 
    *   @return: true - if data members are in a valid state
    *            false - if not
    */
    
    public boolean validate(){
        if (username == null || username.equals("")) return false;
        if (password == null || password.equals("")) return false;
        return true;
    }   
}